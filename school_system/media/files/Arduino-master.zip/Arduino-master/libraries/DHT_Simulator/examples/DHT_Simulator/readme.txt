
2020-12-19

This is a copy of the .ino file from the root folder.
It is placed here so Arduino-CI will compile it.

TODO - check if github can work with symbolic links.

